CREATE TRIGGER `role_after_insert`
AFTER INSERT ON `users`
FOR EACH ROW
  INSERT INTO user_roles (username, role_name) VALUES (new.username, new.role_name)